
import os
import sqlite3
from functools import wraps
from datetime import datetime
from pathlib import Path

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, abort, g
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "instance" / "site.db"
UPLOAD_DIR = BASE_DIR / "static" / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-key")
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = str(UPLOAD_DIR)

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'author',
            bio TEXT DEFAULT '',
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            slug TEXT UNIQUE NOT NULL
        );

        CREATE TABLE IF NOT EXISTS articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            slug TEXT UNIQUE NOT NULL,
            summary TEXT NOT NULL,
            body TEXT NOT NULL,
            cover_image TEXT DEFAULT '',
            category_id INTEGER,
            author_id INTEGER,
            status TEXT NOT NULL DEFAULT 'draft',
            featured INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            published_at TEXT,
            FOREIGN KEY(category_id) REFERENCES categories(id),
            FOREIGN KEY(author_id) REFERENCES users(id)
        );
        """
    )

    categories = [
        ("Gündem", "gundem"),
        ("Siyaset", "siyaset"),
        ("Dış Politika", "dis-politika"),
        ("Felsefe", "felsefe"),
        ("Edebiyat", "edebiyat"),
        ("Toplum ve Kültür", "toplum-kultur"),
        ("Araştırma", "arastirma"),
    ]
    db.executemany(
        "INSERT OR IGNORE INTO categories(name, slug) VALUES (?, ?)",
        categories
    )

    admin_email = os.environ.get("ADMIN_EMAIL", "admin@esik.local")
    admin_password = os.environ.get("ADMIN_PASSWORD", "Degistir123!")
    existing = db.execute(
        "SELECT id FROM users WHERE email = ?", (admin_email,)
    ).fetchone()
    if not existing:
        db.execute(
            """
            INSERT INTO users(name, email, password_hash, role, bio, created_at)
            VALUES (?, ?, ?, 'admin', ?, ?)
            """,
            (
                "Kurucu Editör",
                admin_email,
                generate_password_hash(admin_password),
                "Kurucu yönetici hesabı",
                datetime.utcnow().isoformat()
            )
        )

    count = db.execute("SELECT COUNT(*) AS c FROM articles").fetchone()["c"]
    if count == 0:
        admin_id = db.execute(
            "SELECT id FROM users WHERE email = ?", (admin_email,)
        ).fetchone()["id"]
        cat_id = db.execute(
            "SELECT id FROM categories WHERE slug = 'siyaset'"
        ).fetchone()["id"]

        now = datetime.utcnow().isoformat()
        db.execute(
            """
            INSERT INTO articles(
                title, slug, summary, body, category_id, author_id,
                status, featured, created_at, updated_at, published_at
            )
            VALUES (?, ?, ?, ?, ?, ?, 'published', 1, ?, ?, ?)
            """,
            (
                "Muhaliflerin sözü neden kuruma dönüşemiyor?",
                "muhaliflerin-sozu-neden-kuruma-donusemiyor",
                "Güçlü kalemlerin sosyal medya akışında erimesi yalnızca görünürlük sorunu değil; kurumsal bir boşluğun sonucudur.",
                """<p>Muhalif çevrelerde güçlü cümleler, keskin gözlemler ve ciddi bir düşünsel birikim var. Fakat bütün bunların ortak bir evi yok.</p>
                <p>Bir tweet birkaç saat yaşar. Kişisel bir blog arşiv oluşturur ama okurunu kendisi bulmak zorundadır. Kurum ise metne yalnızca yer vermez; ona süreklilik, editoryal güven ve toplumsal hafıza kazandırır.</p>
                <h2>Kalem var, taşıyıcı yapı yok</h2>
                <p>Entelektüel ağırlık yalnızca iyi yazının değil; arşivin, editörlüğün ve sürekliliğin ürünüdür.</p>""",
                cat_id,
                admin_id,
                now, now, now
            )
        )

    db.commit()
    db.close()


def slugify(value):
    mapping = str.maketrans(
        "çğıöşüÇĞİÖŞÜ",
        "cgiosuCGIOSU"
    )
    value = value.translate(mapping).lower().strip()
    value = "".join(ch if ch.isalnum() else "-" for ch in value)
    while "--" in value:
        value = value.replace("--", "-")
    return value.strip("-")


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("admin_login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("role") != "admin":
            abort(403)
        return view(*args, **kwargs)
    return wrapped


@app.context_processor
def inject_globals():
    db = get_db()
    categories = db.execute(
        "SELECT * FROM categories ORDER BY name"
    ).fetchall()
    return {"nav_categories": categories}


@app.route("/")
def home():
    db = get_db()
    featured = db.execute(
        """
        SELECT a.*, c.name AS category_name, c.slug AS category_slug,
               u.name AS author_name
        FROM articles a
        LEFT JOIN categories c ON a.category_id = c.id
        LEFT JOIN users u ON a.author_id = u.id
        WHERE a.status = 'published'
        ORDER BY a.featured DESC, a.published_at DESC
        LIMIT 5
        """
    ).fetchall()

    latest = db.execute(
        """
        SELECT a.*, c.name AS category_name, c.slug AS category_slug,
               u.name AS author_name
        FROM articles a
        LEFT JOIN categories c ON a.category_id = c.id
        LEFT JOIN users u ON a.author_id = u.id
        WHERE a.status = 'published'
        ORDER BY a.published_at DESC
        LIMIT 12
        """
    ).fetchall()
    return render_template("home.html", featured=featured, latest=latest)


@app.route("/yazilar")
def articles():
    db = get_db()
    rows = db.execute(
        """
        SELECT a.*, c.name AS category_name, c.slug AS category_slug,
               u.name AS author_name
        FROM articles a
        LEFT JOIN categories c ON a.category_id = c.id
        LEFT JOIN users u ON a.author_id = u.id
        WHERE a.status = 'published'
        ORDER BY a.published_at DESC
        """
    ).fetchall()
    return render_template("articles.html", articles=rows)


@app.route("/yazi/<slug>")
def article_detail(slug):
    db = get_db()
    article = db.execute(
        """
        SELECT a.*, c.name AS category_name, c.slug AS category_slug,
               u.name AS author_name, u.bio AS author_bio
        FROM articles a
        LEFT JOIN categories c ON a.category_id = c.id
        LEFT JOIN users u ON a.author_id = u.id
        WHERE a.slug = ? AND a.status = 'published'
        """,
        (slug,)
    ).fetchone()
    if not article:
        abort(404)
    return render_template("article_detail.html", article=article)


@app.route("/kategori/<slug>")
def category_page(slug):
    db = get_db()
    category = db.execute(
        "SELECT * FROM categories WHERE slug = ?", (slug,)
    ).fetchone()
    if not category:
        abort(404)
    rows = db.execute(
        """
        SELECT a.*, u.name AS author_name
        FROM articles a
        LEFT JOIN users u ON a.author_id = u.id
        WHERE a.category_id = ? AND a.status = 'published'
        ORDER BY a.published_at DESC
        """,
        (category["id"],)
    ).fetchall()
    return render_template("category.html", category=category, articles=rows)


@app.route("/yazarlar")
def authors():
    db = get_db()
    rows = db.execute(
        "SELECT id, name, bio, role FROM users ORDER BY name"
    ).fetchall()
    return render_template("authors.html", authors=rows)


@app.route("/yazar/<int:user_id>")
def author_detail(user_id):
    db = get_db()
    author = db.execute(
        "SELECT id, name, bio, role FROM users WHERE id = ?", (user_id,)
    ).fetchone()
    if not author:
        abort(404)
    rows = db.execute(
        """
        SELECT a.*, c.name AS category_name
        FROM articles a
        LEFT JOIN categories c ON a.category_id = c.id
        WHERE a.author_id = ? AND a.status = 'published'
        ORDER BY a.published_at DESC
        """,
        (user_id,)
    ).fetchall()
    return render_template("author_detail.html", author=author, articles=rows)


@app.route("/hakkimizda")
def about():
    return render_template("about.html")


@app.route("/yayin-ilkeleri")
def principles():
    return render_template("principles.html")


@app.route("/iletisim", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        flash("Mesajınız alındı. Gerçek e-posta bağlantısı yayın aşamasında etkinleştirilecektir.", "success")
        return redirect(url_for("contact"))
    return render_template("contact.html")


@app.route("/ara")
def search():
    query = request.args.get("q", "").strip()
    results = []
    if query:
        db = get_db()
        like = f"%{query}%"
        results = db.execute(
            """
            SELECT a.*, c.name AS category_name, u.name AS author_name
            FROM articles a
            LEFT JOIN categories c ON a.category_id = c.id
            LEFT JOIN users u ON a.author_id = u.id
            WHERE a.status = 'published'
              AND (a.title LIKE ? OR a.summary LIKE ? OR a.body LIKE ?)
            ORDER BY a.published_at DESC
            """,
            (like, like, like)
        ).fetchall()
    return render_template("search.html", query=query, results=results)


@app.route("/yonetim/giris", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute(
            "SELECT * FROM users WHERE email = ?", (email,)
        ).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["name"] = user["name"]
            session["role"] = user["role"]
            return redirect(url_for("admin_dashboard"))
        flash("E-posta veya şifre hatalı.", "error")
    return render_template("admin_login.html")


@app.route("/yonetim/cikis")
def admin_logout():
    session.clear()
    return redirect(url_for("home"))


@app.route("/yonetim")
@login_required
def admin_dashboard():
    db = get_db()
    if session.get("role") == "admin":
        rows = db.execute(
            """
            SELECT a.*, c.name AS category_name, u.name AS author_name
            FROM articles a
            LEFT JOIN categories c ON a.category_id = c.id
            LEFT JOIN users u ON a.author_id = u.id
            ORDER BY a.updated_at DESC
            """
        ).fetchall()
    else:
        rows = db.execute(
            """
            SELECT a.*, c.name AS category_name, u.name AS author_name
            FROM articles a
            LEFT JOIN categories c ON a.category_id = c.id
            LEFT JOIN users u ON a.author_id = u.id
            WHERE a.author_id = ?
            ORDER BY a.updated_at DESC
            """,
            (session["user_id"],)
        ).fetchall()
    return render_template("admin_dashboard.html", articles=rows)


@app.route("/yonetim/yazi/yeni", methods=["GET", "POST"])
@login_required
def admin_article_new():
    db = get_db()
    categories = db.execute("SELECT * FROM categories ORDER BY name").fetchall()
    authors = db.execute("SELECT id, name FROM users ORDER BY name").fetchall()

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        slug = request.form.get("slug", "").strip() or slugify(title)
        summary = request.form.get("summary", "").strip()
        body = request.form.get("body", "").strip()
        category_id = request.form.get("category_id") or None
        status = request.form.get("status", "draft")
        featured = 1 if request.form.get("featured") else 0

        if session.get("role") == "admin":
            author_id = request.form.get("author_id") or session["user_id"]
        else:
            author_id = session["user_id"]
            if status == "published":
                status = "review"

        cover_image = ""
        file = request.files.get("cover_image")
        if file and file.filename and allowed_file(file.filename):
            filename = f"{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{secure_filename(file.filename)}"
            file.save(UPLOAD_DIR / filename)
            cover_image = f"uploads/{filename}"

        now = datetime.utcnow().isoformat()
        published_at = now if status == "published" else None

        try:
            db.execute(
                """
                INSERT INTO articles(
                    title, slug, summary, body, cover_image, category_id,
                    author_id, status, featured, created_at, updated_at, published_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    title, slug, summary, body, cover_image, category_id,
                    author_id, status, featured, now, now, published_at
                )
            )
            db.commit()
            flash("Yazı kaydedildi.", "success")
            return redirect(url_for("admin_dashboard"))
        except sqlite3.IntegrityError:
            flash("Bu bağlantı adı zaten kullanılıyor.", "error")

    return render_template(
        "admin_article_form.html",
        article=None,
        categories=categories,
        authors=authors
    )


@app.route("/yonetim/yazi/<int:article_id>/duzenle", methods=["GET", "POST"])
@login_required
def admin_article_edit(article_id):
    db = get_db()
    article = db.execute(
        "SELECT * FROM articles WHERE id = ?", (article_id,)
    ).fetchone()
    if not article:
        abort(404)
    if session.get("role") != "admin" and article["author_id"] != session["user_id"]:
        abort(403)

    categories = db.execute("SELECT * FROM categories ORDER BY name").fetchall()
    authors = db.execute("SELECT id, name FROM users ORDER BY name").fetchall()

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        slug = request.form.get("slug", "").strip() or slugify(title)
        summary = request.form.get("summary", "").strip()
        body = request.form.get("body", "").strip()
        category_id = request.form.get("category_id") or None
        status = request.form.get("status", "draft")
        featured = 1 if request.form.get("featured") else 0
        author_id = request.form.get("author_id") if session.get("role") == "admin" else article["author_id"]

        if session.get("role") != "admin" and status == "published":
            status = "review"

        cover_image = article["cover_image"]
        file = request.files.get("cover_image")
        if file and file.filename and allowed_file(file.filename):
            filename = f"{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{secure_filename(file.filename)}"
            file.save(UPLOAD_DIR / filename)
            cover_image = f"uploads/{filename}"

        published_at = article["published_at"]
        if status == "published" and not published_at:
            published_at = datetime.utcnow().isoformat()

        db.execute(
            """
            UPDATE articles
            SET title=?, slug=?, summary=?, body=?, cover_image=?,
                category_id=?, author_id=?, status=?, featured=?,
                updated_at=?, published_at=?
            WHERE id=?
            """,
            (
                title, slug, summary, body, cover_image, category_id,
                author_id, status, featured, datetime.utcnow().isoformat(),
                published_at, article_id
            )
        )
        db.commit()
        flash("Yazı güncellendi.", "success")
        return redirect(url_for("admin_dashboard"))

    return render_template(
        "admin_article_form.html",
        article=article,
        categories=categories,
        authors=authors
    )


@app.route("/yonetim/yazi/<int:article_id>/sil", methods=["POST"])
@login_required
@admin_required
def admin_article_delete(article_id):
    db = get_db()
    db.execute("DELETE FROM articles WHERE id = ?", (article_id,))
    db.commit()
    flash("Yazı silindi.", "success")
    return redirect(url_for("admin_dashboard"))


@app.route("/yonetim/yazarlar", methods=["GET", "POST"])
@login_required
@admin_required
def admin_users():
    db = get_db()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        role = request.form.get("role", "author")
        bio = request.form.get("bio", "").strip()
        try:
            db.execute(
                """
                INSERT INTO users(name, email, password_hash, role, bio, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    name, email, generate_password_hash(password),
                    role, bio, datetime.utcnow().isoformat()
                )
            )
            db.commit()
            flash("Yeni kullanıcı eklendi.", "success")
            return redirect(url_for("admin_users"))
        except sqlite3.IntegrityError:
            flash("Bu e-posta adresi zaten kayıtlı.", "error")

    users = db.execute(
        "SELECT id, name, email, role, bio FROM users ORDER BY name"
    ).fetchall()
    return render_template("admin_users.html", users=users)


@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html"), 404


if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
