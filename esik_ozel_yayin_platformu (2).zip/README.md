# Eşik Özel Yayın Platformu

Bu proje WordPress kullanmaz. Flask + SQLite ile geliştirilmiş, özel yönetim panelli gerçek bir web uygulamasıdır.

## Özellikler

- Ana sayfa
- Yazılar arşivi
- Kategoriler
- Yazar profilleri
- Yazı detay sayfaları
- Arama
- Enstitü / hakkımızda
- Yayın ilkeleri
- İletişim
- Yönetim paneli
- Admin, editör ve yazar rolleri
- Taslak, inceleme ve yayımlama akışı
- Kapak görseli yükleme
- Öne çıkan yazı sistemi
- SQLite veritabanı

## Yerelde çalıştırma

1. Python 3.11 veya üstünü kurun.
2. Terminali bu klasörde açın.
3. Sanal ortam oluşturun:

Windows:
```bash
python -m venv .venv
.venv\Scripts\activate
```

macOS / Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

4. Paketleri kurun:
```bash
pip install -r requirements.txt
```

5. Uygulamayı başlatın:
```bash
python app.py
```

6. Tarayıcıda:
```text
http://127.0.0.1:5000
```

Yönetim paneli:
```text
http://127.0.0.1:5000/yonetim/giris
```

İlk giriş:
- E-posta: `admin@esik.local`
- Şifre: `Degistir123!`

## Güvenlik

Yayınlamadan önce ortam değişkenlerini değiştirin:

```bash
SECRET_KEY=uzun-ve-rastgele-bir-anahtar
ADMIN_EMAIL=gercek@eposta.com
ADMIN_PASSWORD=guclu-bir-sifre
```

## İnternete yayınlama

Bu proje Render, Railway, Fly.io, VPS veya klasik Python hosting üzerinde çalıştırılabilir.

### Gunicorn komutu
```bash
gunicorn app:app
```

### Önemli
SQLite küçük ekipler için uygundur. Trafik büyüdüğünde PostgreSQL'e geçilmesi önerilir.

## Alan adı

Alan adı ve hosting hesabı sizin adınıza açılmalıdır. Bunun nedeni:
- alan adının hukuki sahibi siz olmalısınız,
- ödeme ve yenileme kontrolü sizde olmalı,
- yönetici şifreleri yalnızca sizde kalmalı,
- platform ileride başka bir geliştiriciye taşınabilmeli.

Kod paketi sunucuya yüklenmeye hazırdır.
